import Typed from 'react-typed'

export default function HeroSection(){
    return (
        <section id="HeroSection" className="hero--section">
            <div className="hero--section--content--box">
                <div className="hero--section--content">
                    <p className="section--title">
                        Hola Bienvenido, Soy Federico Bernart, soy
                    </p>
                    
                    {<Typed strings={[
                        "Ingeniero Electrónico",
                        "Jr. DevOps Engineer",
                    ]}
                    typeSpeed={100}
                    backSpeed={50}
                    loop
                    className='hero--section--title hero--section--title--color'
                    />}
                    <p className="hero--section--description">
                        Egresado de la Universidad Nacional de San Juan. Ingeniero especialista en Sistemas de control y Telecomunicaciones.
                        <br />
                        <br />
                        Con experiencia en administración de servidores y diseño de electrónica analógica y digital.
                        <br />
                        <br />
                        Proactivo, nerd apasionado del mundo de la tecnología
                    </p>
                </div>
                <button className="btn btn-primary">Contactame por WhatsApp</button>
            </div>
            <div className="hero--section--img">
                <img src="./img/hero_img.png" alt="Hero Section" />
            </div>
        </section>
    )
}